## Test environments
* local Ubuntu 16.04 install, R 3.4.3
* ubuntu 14.04 (on travis-ci), R 3.4.3
* OS X (on travis-ci), R 3.4.3
* win-builder (devel and release)

## R CMD check results

OK

## Reverse dependencies

Checked all 6 downstream dependencies, no regressions found.
